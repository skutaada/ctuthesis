#Drone detection using LiDAR and RGB data
CTU bachelor thesis

The class files are:
ctuthesis.cls (the class)
ctuth-core.tex
ctuth-names.tex
ctuth-pkg.tex
ctuth-templates.tex
ctu_logo_black.pdf (licensed by CTU)
ctu_logo_blue.pdf (licensed by CTU)
ctuthesis.ist
ctuman.pdf (the manual)
ctuman* (the manual's code)

The test files are:
ctutest.tex
ctutest-1.tex
ctutest-2.tex
ctutest-zadani.pdf
ctutest.bib
ctutest.* (auxiliary files)
